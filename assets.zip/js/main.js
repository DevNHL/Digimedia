var mensaje = "hola mundo";
console.log(mensaje);